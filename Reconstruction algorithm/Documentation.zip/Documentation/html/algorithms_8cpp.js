var algorithms_8cpp =
[
    [ "fienup_algorithm", "algorithms_8cpp.html#ae3c60da0d2e5898d9ca443ac260160ba", null ],
    [ "RI_algorithme_FISTA", "algorithms_8cpp.html#aa8cc1e0e4c07831b80ebebae35443831", null ],
    [ "RI_algorithme_ISTA", "algorithms_8cpp.html#a95606f91061bf91fe905d902887c52fe", null ],
    [ "simple_backpropagation", "algorithms_8cpp.html#a39ba5a7c559d5ce478d4a7f8441079e4", null ]
];