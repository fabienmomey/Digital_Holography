var annotated_dup =
[
    [ "Settings", "struct_settings.html", "struct_settings" ]
];