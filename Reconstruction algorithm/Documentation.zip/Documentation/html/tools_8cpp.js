var tools_8cpp =
[
    [ "complex_display", "tools_8cpp.html#a8739475e07e59cdb0c3e870f6fa130cb", null ],
    [ "complex_multiply", "tools_8cpp.html#a822b8a30a8a1757195b23c7170caeb0c", null ],
    [ "complex_multiply", "tools_8cpp.html#af6575797414b2c1b14f87161c0d66698", null ],
    [ "FT_shift", "tools_8cpp.html#a3650e582c6bce09cc3153e96a2258dc5", null ],
    [ "get_fresnel_propagator", "tools_8cpp.html#a267a4b95ceaf5b85bad202ff4e1bffb8", null ],
    [ "image_calibration", "tools_8cpp.html#aeb7d2ccfa50c44325f0419e4d046d52a", null ],
    [ "my_multiply", "tools_8cpp.html#aedb437aefb99388c1b74bc54d4a646a7", null ],
    [ "optimal_FT", "tools_8cpp.html#aefe2fda6924aa64cca8cc8240a1f322c", null ],
    [ "padding", "tools_8cpp.html#a015bcf3fae00e56ad2d866d304c79f82", null ]
];