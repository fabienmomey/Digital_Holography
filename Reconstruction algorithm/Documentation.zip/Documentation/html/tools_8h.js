var tools_8h =
[
    [ "Settings", "struct_settings.html", "struct_settings" ],
    [ "EXTREMUMS", "tools_8h.html#a6fb6bcd343d889b5faaf3a8bfe258b78", null ],
    [ "CalculMethod", "tools_8h.html#a0a94f49172c13a7eb750e347d008afc1", [
      [ "MODULE_CALCUL", "tools_8h.html#a0a94f49172c13a7eb750e347d008afc1a50acc11321335c0c78d6f8148086e835", null ],
      [ "PHASE_CALCUL", "tools_8h.html#a0a94f49172c13a7eb750e347d008afc1aacd033bfbc1167b788d17244b6941daa", null ]
    ] ],
    [ "HOLOGRAM_TYPE", "tools_8h.html#a6145cb29fa5db2bad757889eae364990", [
      [ "COMPLEX", "tools_8h.html#a6145cb29fa5db2bad757889eae364990a5374e1234e4d55af346d6ae6263ad573", null ],
      [ "INTENSITY", "tools_8h.html#a6145cb29fa5db2bad757889eae364990a2cdcc599a48dff7249efc882c4858e54", null ]
    ] ],
    [ "KERNEL_TYPE", "tools_8h.html#aae41d3f5a89b7201fca2cfc32a99667e", [
      [ "HZ", "tools_8h.html#aae41d3f5a89b7201fca2cfc32a99667ea60bcd2a30600425969cffd701375c9f2", null ],
      [ "GZ_DEPHASING", "tools_8h.html#aae41d3f5a89b7201fca2cfc32a99667ea3aa4665fe1368c4ab42f71c46c27bf93", null ],
      [ "GZ_ABSORBING", "tools_8h.html#aae41d3f5a89b7201fca2cfc32a99667ea4b5cfde6300168f28e8e7be982549357", null ]
    ] ],
    [ "OBJ_TYPE", "tools_8h.html#a714b9c2c276fbae637fee36453d9121e", [
      [ "DEPHASING", "tools_8h.html#a714b9c2c276fbae637fee36453d9121ea1aeeb395139e7c6e107c6f260ae869df", null ],
      [ "ABSORBING", "tools_8h.html#a714b9c2c276fbae637fee36453d9121ea800b2b229a408c3f50bb165976d512c4", null ]
    ] ],
    [ "complex_display", "tools_8h.html#aee42b5b9a3b3d962c66bbd390f7e1dca", null ],
    [ "complex_multiply", "tools_8h.html#a822b8a30a8a1757195b23c7170caeb0c", null ],
    [ "complex_multiply", "tools_8h.html#af6575797414b2c1b14f87161c0d66698", null ],
    [ "FT_shift", "tools_8h.html#a3650e582c6bce09cc3153e96a2258dc5", null ],
    [ "get_fresnel_propagator", "tools_8h.html#af9c514ea8d724c25e3c1159cf5f36b46", null ],
    [ "image_calibration", "tools_8h.html#aeb7d2ccfa50c44325f0419e4d046d52a", null ],
    [ "my_multiply", "tools_8h.html#aedb437aefb99388c1b74bc54d4a646a7", null ],
    [ "optimal_FT", "tools_8h.html#aefe2fda6924aa64cca8cc8240a1f322c", null ],
    [ "padding", "tools_8h.html#a015bcf3fae00e56ad2d866d304c79f82", null ]
];