var struct_settings =
[
    [ "height", "struct_settings.html#af63a2c25f93b1f54a88f9217e95fbcc0", null ],
    [ "lambda", "struct_settings.html#a1ee477f5c677e96237fe42d315200fcf", null ],
    [ "mag", "struct_settings.html#a8dbc215399733219bede05d854ff82ef", null ],
    [ "n0", "struct_settings.html#aff398b517cf4a18e239b609ec0d91762", null ],
    [ "pixel_size", "struct_settings.html#a08401558c77975b7babbea94b2d6f5fc", null ],
    [ "width", "struct_settings.html#ac5a707ab0e620e9aeb22d98478197506", null ],
    [ "z", "struct_settings.html#aafaf12202dfa59ae213031d48f93929f", null ]
];