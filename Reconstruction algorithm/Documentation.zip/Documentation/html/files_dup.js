var files_dup =
[
    [ "algorithms.cpp", "algorithms_8cpp.html", "algorithms_8cpp" ],
    [ "algorithms.h", "algorithms_8h.html", "algorithms_8h" ],
    [ "Fienup_algorithm.cpp", "_fienup__algorithm_8cpp.html", "_fienup__algorithm_8cpp" ],
    [ "FISTA_algorithm.cpp", "_f_i_s_t_a__algorithm_8cpp.html", "_f_i_s_t_a__algorithm_8cpp" ],
    [ "tools.cpp", "tools_8cpp.html", "tools_8cpp" ],
    [ "tools.h", "tools_8h.html", "tools_8h" ]
];