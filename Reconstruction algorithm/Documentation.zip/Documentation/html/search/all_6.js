var searchData=
[
  ['get_5ffresnel_5fpropagator_16',['get_fresnel_propagator',['../tools_8cpp.html#a267a4b95ceaf5b85bad202ff4e1bffb8',1,'get_fresnel_propagator(const Settings &amp;setting, Mat &amp;Hz, Mat &amp;H_z, bool flag_phaseref, HOLOGRAM_TYPE hologram_type, bool flag_linearize, OBJ_TYPE object_type):&#160;tools.cpp'],['../tools_8h.html#af9c514ea8d724c25e3c1159cf5f36b46',1,'get_fresnel_propagator(const Settings &amp;setting, Mat &amp;Hz, Mat &amp;H_z, bool flag_phaseref=false, HOLOGRAM_TYPE hologram_type=COMPLEX, bool flag_linearize=false, OBJ_TYPE object_type=DEPHASING):&#160;tools.cpp']]],
  ['gz_5fabsorbing_17',['GZ_ABSORBING',['../tools_8h.html#aae41d3f5a89b7201fca2cfc32a99667ea4b5cfde6300168f28e8e7be982549357',1,'tools.h']]],
  ['gz_5fdephasing_18',['GZ_DEPHASING',['../tools_8h.html#aae41d3f5a89b7201fca2cfc32a99667ea3aa4665fe1368c4ab42f71c46c27bf93',1,'tools.h']]]
];
