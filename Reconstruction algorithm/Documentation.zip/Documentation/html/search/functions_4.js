var searchData=
[
  ['main_63',['main',['../_fienup__algorithm_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;Fienup_algorithm.cpp'],['../_r_i__algorithm_8cpp.html#a0ddf1224851353fc92bfbff6f499fa97',1,'main(int argc, char *argv[]):&#160;RI_algorithm.cpp'],['../test_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;test.cpp']]],
  ['my_5fmultiply_64',['my_multiply',['../tools_8cpp.html#aedb437aefb99388c1b74bc54d4a646a7',1,'my_multiply(const Mat &amp;simple_mat, const Mat &amp;complex_mat, Mat &amp;res_mat):&#160;tools.cpp'],['../tools_8h.html#aedb437aefb99388c1b74bc54d4a646a7',1,'my_multiply(const Mat &amp;simple_mat, const Mat &amp;complex_mat, Mat &amp;res_mat):&#160;tools.cpp']]]
];
