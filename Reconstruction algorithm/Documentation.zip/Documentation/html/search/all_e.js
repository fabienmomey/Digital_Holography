var searchData=
[
  ['padding_33',['padding',['../tools_8cpp.html#a015bcf3fae00e56ad2d866d304c79f82',1,'padding(const Mat &amp;initial_mat, const int x, const int y, const int pad, Mat &amp;resized_mat):&#160;tools.cpp'],['../tools_8h.html#a015bcf3fae00e56ad2d866d304c79f82',1,'padding(const Mat &amp;initial_mat, const int x, const int y, const int pad, Mat &amp;resized_mat):&#160;tools.cpp']]],
  ['phase_5fcalcul_34',['PHASE_CALCUL',['../tools_8h.html#a0a94f49172c13a7eb750e347d008afc1aacd033bfbc1167b788d17244b6941daa',1,'tools.h']]],
  ['pixel_5fsize_35',['pixel_size',['../struct_settings.html#a08401558c77975b7babbea94b2d6f5fc',1,'Settings']]],
  ['program_36',['program',['../_input_01_parameters_01of_01algorithms_8txt.html#a3689583fd050b7c2c9c935e3fdbff234',1,'Input Parameters of algorithms.txt']]]
];
