var searchData=
[
  ['image_5fcalibration_62',['image_calibration',['../tools_8cpp.html#aeb7d2ccfa50c44325f0419e4d046d52a',1,'image_calibration(const Mat &amp;initial_hologram, Mat &amp;optimal_hologram, int do_padding, int do_sqrt):&#160;tools.cpp'],['../tools_8h.html#aeb7d2ccfa50c44325f0419e4d046d52a',1,'image_calibration(const Mat &amp;initial_hologram, Mat &amp;optimal_hologram, int do_padding, int do_sqrt):&#160;tools.cpp']]]
];
