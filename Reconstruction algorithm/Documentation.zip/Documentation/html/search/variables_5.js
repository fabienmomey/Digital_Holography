var searchData=
[
  ['pixel_5fsize_76',['pixel_size',['../struct_settings.html#a08401558c77975b7babbea94b2d6f5fc',1,'Settings']]],
  ['program_77',['program',['../_input_01_parameters_01of_01algorithms_8txt.html#a3689583fd050b7c2c9c935e3fdbff234',1,'Input Parameters of algorithms.txt']]]
];
