var searchData=
[
  ['z_47',['z',['../struct_settings.html#aafaf12202dfa59ae213031d48f93929f',1,'Settings']]]
];
