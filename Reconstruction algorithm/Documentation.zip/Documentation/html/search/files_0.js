var searchData=
[
  ['algorithms_2ecpp_48',['algorithms.cpp',['../algorithms_8cpp.html',1,'']]],
  ['algorithms_2eh_49',['algorithms.h',['../algorithms_8h.html',1,'']]]
];
