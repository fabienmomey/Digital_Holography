var searchData=
[
  ['fienup_5falgorithm_56',['fienup_algorithm',['../algorithms_8cpp.html#ae3c60da0d2e5898d9ca443ac260160ba',1,'fienup_algorithm(const Mat &amp;optimal_hologram, Mat &amp;reconstituted_image, Settings &amp;setting, int object, double complex_extremum[], int repetitions):&#160;algorithms.cpp'],['../algorithms_8h.html#ae3c60da0d2e5898d9ca443ac260160ba',1,'fienup_algorithm(const Mat &amp;optimal_hologram, Mat &amp;reconstituted_image, Settings &amp;setting, int object, double complex_extremum[], int repetitions):&#160;algorithms.cpp']]],
  ['ft_5fshift_57',['FT_shift',['../tools_8cpp.html#a3650e582c6bce09cc3153e96a2258dc5',1,'FT_shift(const Mat &amp;initial_mat, Mat &amp;final_mat):&#160;tools.cpp'],['../tools_8h.html#a3650e582c6bce09cc3153e96a2258dc5',1,'FT_shift(const Mat &amp;initial_mat, Mat &amp;final_mat):&#160;tools.cpp']]]
];
