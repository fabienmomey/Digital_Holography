var searchData=
[
  ['width_46',['width',['../struct_settings.html#ac5a707ab0e620e9aeb22d98478197506',1,'Settings']]]
];
