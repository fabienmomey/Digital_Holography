var searchData=
[
  ['settings_40',['Settings',['../struct_settings.html',1,'']]],
  ['simple_5fbackpropagation_41',['simple_backpropagation',['../algorithms_8cpp.html#a39ba5a7c559d5ce478d4a7f8441079e4',1,'simple_backpropagation(const Mat &amp;optimal_hologram, Mat &amp;reconstituted_image, Settings &amp;setting):&#160;algorithms.cpp'],['../algorithms_8h.html#a39ba5a7c559d5ce478d4a7f8441079e4',1,'simple_backpropagation(const Mat &amp;optimal_hologram, Mat &amp;reconstituted_image, Settings &amp;setting):&#160;algorithms.cpp']]]
];
