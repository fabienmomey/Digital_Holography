var searchData=
[
  ['settings_40',['Settings',['../struct_settings.html',1,'']]]
];
