var searchData=
[
  ['obj_5ftype_31',['OBJ_TYPE',['../tools_8h.html#a714b9c2c276fbae637fee36453d9121e',1,'tools.h']]],
  ['optimal_5fft_32',['optimal_FT',['../tools_8cpp.html#aefe2fda6924aa64cca8cc8240a1f322c',1,'optimal_FT(const Mat &amp;initial_mat, const int pad, Mat &amp;final_mat):&#160;tools.cpp'],['../tools_8h.html#aefe2fda6924aa64cca8cc8240a1f322c',1,'optimal_FT(const Mat &amp;initial_mat, const int pad, Mat &amp;final_mat):&#160;tools.cpp']]]
];
