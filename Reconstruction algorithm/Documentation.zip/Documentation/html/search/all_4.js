var searchData=
[
  ['extremums_11',['EXTREMUMS',['../tools_8h.html#a6fb6bcd343d889b5faaf3a8bfe258b78',1,'tools.h']]]
];
