var searchData=
[
  ['height_19',['height',['../struct_settings.html#af63a2c25f93b1f54a88f9217e95fbcc0',1,'Settings']]],
  ['hologram_5ftype_20',['HOLOGRAM_TYPE',['../tools_8h.html#a6145cb29fa5db2bad757889eae364990',1,'tools.h']]],
  ['hz_21',['HZ',['../tools_8h.html#aae41d3f5a89b7201fca2cfc32a99667ea60bcd2a30600425969cffd701375c9f2',1,'tools.h']]]
];
