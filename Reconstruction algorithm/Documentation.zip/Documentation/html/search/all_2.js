var searchData=
[
  ['calculmethod_5',['CalculMethod',['../tools_8h.html#a0a94f49172c13a7eb750e347d008afc1',1,'tools.h']]],
  ['complex_6',['COMPLEX',['../tools_8h.html#a6145cb29fa5db2bad757889eae364990a5374e1234e4d55af346d6ae6263ad573',1,'tools.h']]],
  ['complex_5fdisplay_7',['complex_display',['../tools_8cpp.html#a8739475e07e59cdb0c3e870f6fa130cb',1,'complex_display(const Mat &amp;initial_mat, Mat &amp;final_mat, CalculMethod method, bool log_scale):&#160;tools.cpp'],['../tools_8h.html#aee42b5b9a3b3d962c66bbd390f7e1dca',1,'complex_display(const Mat &amp;initial_mat, Mat &amp;final_mat, CalculMethod method, bool log_scale=false):&#160;tools.cpp']]],
  ['complex_5fmultiply_8',['complex_multiply',['../tools_8cpp.html#af6575797414b2c1b14f87161c0d66698',1,'complex_multiply(const Mat &amp;mat1, const Mat &amp;mat2, Mat &amp;res_mat):&#160;tools.cpp'],['../tools_8cpp.html#a822b8a30a8a1757195b23c7170caeb0c',1,'complex_multiply(const complex&lt; double &gt; &amp;complex_scalar, const Mat &amp;complex_mat, Mat &amp;res_mat):&#160;tools.cpp'],['../tools_8h.html#af6575797414b2c1b14f87161c0d66698',1,'complex_multiply(const Mat &amp;mat1, const Mat &amp;mat2, Mat &amp;res_mat):&#160;tools.cpp'],['../tools_8h.html#a822b8a30a8a1757195b23c7170caeb0c',1,'complex_multiply(const complex&lt; double &gt; &amp;complex_scalar, const Mat &amp;complex_mat, Mat &amp;res_mat):&#160;tools.cpp']]]
];
