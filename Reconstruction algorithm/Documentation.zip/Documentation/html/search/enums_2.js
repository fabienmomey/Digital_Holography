var searchData=
[
  ['kernel_5ftype_76',['KERNEL_TYPE',['../tools_8h.html#aae41d3f5a89b7201fca2cfc32a99667e',1,'tools.h']]]
];
