var searchData=
[
  ['gz_5fabsorbing_87',['GZ_ABSORBING',['../tools_8h.html#aae41d3f5a89b7201fca2cfc32a99667ea4b5cfde6300168f28e8e7be982549357',1,'tools.h']]],
  ['gz_5fdephasing_88',['GZ_DEPHASING',['../tools_8h.html#aae41d3f5a89b7201fca2cfc32a99667ea3aa4665fe1368c4ab42f71c46c27bf93',1,'tools.h']]]
];
