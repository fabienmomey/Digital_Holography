var searchData=
[
  ['image_5fcalibration_22',['image_calibration',['../tools_8cpp.html#aeb7d2ccfa50c44325f0419e4d046d52a',1,'image_calibration(const Mat &amp;initial_hologram, Mat &amp;optimal_hologram, int do_padding, int do_sqrt):&#160;tools.cpp'],['../tools_8h.html#aeb7d2ccfa50c44325f0419e4d046d52a',1,'image_calibration(const Mat &amp;initial_hologram, Mat &amp;optimal_hologram, int do_padding, int do_sqrt):&#160;tools.cpp']]],
  ['input_20parameters_20of_20algorithms_2etxt_23',['Input Parameters of algorithms.txt',['../_input_01_parameters_01of_01algorithms_8txt.html',1,'']]],
  ['intensity_24',['INTENSITY',['../tools_8h.html#a6145cb29fa5db2bad757889eae364990a2cdcc599a48dff7249efc882c4858e54',1,'tools.h']]]
];
