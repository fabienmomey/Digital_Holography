var searchData=
[
  ['settings_47',['Settings',['../struct_settings.html',1,'']]]
];
