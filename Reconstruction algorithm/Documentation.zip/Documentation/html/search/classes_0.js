var searchData=
[
  ['settings_48',['Settings',['../struct_settings.html',1,'']]]
];
