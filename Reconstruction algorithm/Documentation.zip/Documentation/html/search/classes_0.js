var searchData=
[
  ['settings_45',['Settings',['../struct_settings.html',1,'']]]
];
