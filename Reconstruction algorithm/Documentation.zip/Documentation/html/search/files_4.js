var searchData=
[
  ['ri_5falgorithm_2ecpp_53',['RI_algorithm.cpp',['../_r_i__algorithm_8cpp.html',1,'']]]
];
