var searchData=
[
  ['calculmethod_74',['CalculMethod',['../tools_8h.html#a0a94f49172c13a7eb750e347d008afc1',1,'tools.h']]]
];
