var searchData=
[
  ['ri_5falgorithm_2ecpp_37',['RI_algorithm.cpp',['../_r_i__algorithm_8cpp.html',1,'']]],
  ['ri_5falgorithme_5ffista_38',['RI_algorithme_FISTA',['../algorithms_8cpp.html#aa8cc1e0e4c07831b80ebebae35443831',1,'RI_algorithme_FISTA(const Mat &amp;optimal_hologram, Mat &amp;reconstituted_image, Settings &amp;setting, int object, double extremum[], int repetitions):&#160;algorithms.cpp'],['../algorithms_8h.html#aa8cc1e0e4c07831b80ebebae35443831',1,'RI_algorithme_FISTA(const Mat &amp;optimal_hologram, Mat &amp;reconstituted_image, Settings &amp;setting, int object, double extremum[], int repetitions):&#160;algorithms.cpp']]],
  ['ri_5falgorithme_5fista_39',['RI_algorithme_ISTA',['../algorithms_8cpp.html#a95606f91061bf91fe905d902887c52fe',1,'RI_algorithme_ISTA(const Mat &amp;optimal_hologram, Mat &amp;reconstituted_image, Settings &amp;setting, int object, double extremum[], int repetitions):&#160;algorithms.cpp'],['../algorithms_8h.html#a95606f91061bf91fe905d902887c52fe',1,'RI_algorithme_ISTA(const Mat &amp;optimal_hologram, Mat &amp;reconstituted_image, Settings &amp;setting, int object, double extremum[], int repetitions):&#160;algorithms.cpp']]]
];
