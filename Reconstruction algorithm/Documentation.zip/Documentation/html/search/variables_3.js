var searchData=
[
  ['mag_74',['mag',['../struct_settings.html#a8dbc215399733219bede05d854ff82ef',1,'Settings']]]
];
