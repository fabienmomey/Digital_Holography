var searchData=
[
  ['padding_66',['padding',['../tools_8cpp.html#a015bcf3fae00e56ad2d866d304c79f82',1,'padding(const Mat &amp;initial_mat, const int x, const int y, const int pad, Mat &amp;resized_mat):&#160;tools.cpp'],['../tools_8h.html#a015bcf3fae00e56ad2d866d304c79f82',1,'padding(const Mat &amp;initial_mat, const int x, const int y, const int pad, Mat &amp;resized_mat):&#160;tools.cpp']]]
];
