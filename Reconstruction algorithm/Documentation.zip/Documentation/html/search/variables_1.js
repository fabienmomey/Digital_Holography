var searchData=
[
  ['height_72',['height',['../struct_settings.html#af63a2c25f93b1f54a88f9217e95fbcc0',1,'Settings']]]
];
