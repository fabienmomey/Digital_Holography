var searchData=
[
  ['lambda_67',['lambda',['../struct_settings.html#a1ee477f5c677e96237fe42d315200fcf',1,'Settings']]]
];
