var searchData=
[
  ['n0_31',['n0',['../struct_settings.html#aff398b517cf4a18e239b609ec0d91762',1,'Settings']]]
];
