var indexSectionsWithContent =
{
  0: "_acdefghiklmnoprstwz",
  1: "s",
  2: "adfirt",
  3: "cfgimoprs",
  4: "hlmnpwz",
  5: "chko",
  6: "acdghimp",
  7: "_e",
  8: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros",
  8: "Pages"
};

